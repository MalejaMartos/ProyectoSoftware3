package Logic;

import java.text.ParseException;

public class main {

	/**
	 * metodo que 
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) {
//		dataConnection connection= new dataConnection();
//		institutoMontenegro instituto= new institutoMontenegro();
//		ResultSet resultado;
//		String nombre;
//		instituto.fechaHoy();
//		instituto.actualizarUltimoIngreso(instituto.fechaHoy());
		


	}

}
